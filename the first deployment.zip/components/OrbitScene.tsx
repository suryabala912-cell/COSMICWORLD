import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars, PerspectiveCamera } from '@react-three/drei';
import { EarthModel } from './Earth';
import { Asteroid } from './Asteroid';

interface OrbitSceneProps {
  asteroids: any[];
  selectedId: string | null;
  onSelectAsteroid: (asteroid: any) => void;
}

export const OrbitScene: React.FC<OrbitSceneProps> = ({ asteroids, selectedId, onSelectAsteroid }) => {
  return (
    <div className="w-full h-full bg-black">
      <Canvas dpr={[1, 2]}>
        <PerspectiveCamera makeDefault position={[0, 15, 30]} fov={45} />
        
        {/* Environment */}
        <Stars radius={300} depth={100} count={5000} factor={4} saturation={0} fade speed={0.5} />
        <ambientLight intensity={0.2} color="#001133" />
        <pointLight position={[10, 10, 10]} intensity={1.5} />

        {/* Center Earth */}
        <Suspense fallback={null}>
            <EarthModel scale={1} />
        </Suspense>

        {/* Orbiting Objects */}
        {asteroids.map((ast) => (
            <Asteroid 
                key={ast.id} 
                data={ast} 
                isSelected={selectedId === ast.id} 
                onSelect={onSelectAsteroid} 
            />
        ))}

        {/* Controls */}
        <OrbitControls 
            enablePan={true}
            enableZoom={true}
            enableRotate={true}
            minDistance={5}
            maxDistance={100}
        />
      </Canvas>
    </div>
  );
};