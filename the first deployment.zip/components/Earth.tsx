import React, { useRef } from 'react';
import { Canvas, useFrame, useLoader } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';

// ------------------------------------------------------------------
// REUSABLE EARTH MODEL
// ------------------------------------------------------------------
export const EarthModel = ({ scale = 1 }) => {
  const earthRef = useRef<THREE.Mesh>(null);
  const cloudsRef = useRef<THREE.Mesh>(null);
  const wireframeRef = useRef<THREE.Mesh>(null);
  const ringsRef = useRef<THREE.Group>(null);

  const [colorMap, bumpMap, specularMap, cloudsMap] = useLoader(THREE.TextureLoader, [
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/141228/earthmap1k.jpg',
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/141228/earthbump1k.jpg',
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/141228/earthspec1k.jpg',
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/141228/earthcloudmap.jpg'
  ]);

  useFrame(({ clock }) => {
    const elapsedTime = clock.getElapsedTime();
    if (earthRef.current) earthRef.current.rotation.y = elapsedTime * 0.05;
    if (cloudsRef.current) cloudsRef.current.rotation.y = elapsedTime * 0.06;
    if (wireframeRef.current) {
        wireframeRef.current.rotation.y = elapsedTime * 0.04;
        wireframeRef.current.rotation.x = Math.sin(elapsedTime * 0.2) * 0.05;
    }
    if (ringsRef.current) {
        ringsRef.current.rotation.y = elapsedTime * 0.02;
        ringsRef.current.rotation.z = Math.PI / 6 + Math.sin(elapsedTime * 0.1) * 0.05;
    }
  });

  return (
    <group scale={[scale, scale, scale]}>
      <ambientLight intensity={0.1} color="#001133" />
      <pointLight position={[50, 20, 30]} intensity={2} color="#ffffff" />
      <directionalLight position={[-10, 5, 0]} intensity={1.5} color="#4b96f3" />
      <directionalLight position={[0, -10, 5]} intensity={0.8} color="#a239ca" />
      
      <mesh ref={earthRef}>
        <sphereGeometry args={[2.5, 64, 64]} />
        <meshPhongMaterial 
          map={colorMap}
          bumpMap={bumpMap}
          bumpScale={0.05}
          specularMap={specularMap}
          specular={new THREE.Color(0x333333)}
          shininess={15}
        />
      </mesh>

      <mesh ref={cloudsRef}>
        <sphereGeometry args={[2.53, 64, 64]} />
        <meshPhongMaterial 
          map={cloudsMap}
          transparent={true}
          opacity={0.6}
          side={THREE.DoubleSide}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>

      <mesh ref={wireframeRef} scale={[1.02, 1.02, 1.02]}>
         <sphereGeometry args={[2.5, 24, 24]} />
         <meshBasicMaterial 
            color="#00ffff"
            wireframe={true}
            transparent={true}
            opacity={0.08}
            blending={THREE.AdditiveBlending}
         />
      </mesh>

      <group ref={ringsRef}>
         <mesh rotation={[Math.PI / 2, 0, 0]}>
            <ringGeometry args={[3.2, 3.22, 128]} />
            <meshBasicMaterial color="#4b96f3" side={THREE.DoubleSide} transparent opacity={0.6} blending={THREE.AdditiveBlending} />
         </mesh>
         <mesh rotation={[Math.PI / 2, 0, 0]}>
            <ringGeometry args={[3.5, 3.52, 64]} />
            <meshBasicMaterial color="#a239ca" side={THREE.DoubleSide} transparent opacity={0.3} blending={THREE.AdditiveBlending} />
         </mesh>
      </group>
      
      <mesh scale={[1.2, 1.2, 1.2]}>
        <sphereGeometry args={[2.5, 32, 32]} />
        <meshBasicMaterial
          color="#1c4e91"
          transparent
          opacity={0.15}
          side={THREE.BackSide}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </group>
  );
};

// ------------------------------------------------------------------
// STANDALONE COMPONENT (Legacy/Background)
// ------------------------------------------------------------------
export const Earth: React.FC = () => {
  return (
    <div className="w-full h-full min-h-[500px] cursor-grab active:cursor-grabbing">
      <Canvas camera={{ position: [0, 5, 18], fov: 45 }} dpr={[1, 2]}>
        <Stars radius={300} depth={60} count={20000} factor={6} saturation={0} fade speed={0.5} />
        <group rotation={[0.3, 0, 0.2]}>
            <EarthModel />
        </group>
        <OrbitControls 
            enableZoom={true} 
            maxDistance={40}
            minDistance={8}
            enablePan={false} 
            enableRotate={true}
            autoRotate={true}
            autoRotateSpeed={0.3}
        />
      </Canvas>
    </div>
  );
};