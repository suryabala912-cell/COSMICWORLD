import React, { useState, useEffect } from 'react';
import { User, Shield, Clock } from 'lucide-react';

interface NavbarProps {
  onProfileClick?: () => void;
  onAdminClick?: () => void;
  userRole?: 'user' | 'admin';
}

export const Navbar: React.FC<NavbarProps> = ({ onProfileClick, onAdminClick, userRole }) => {
  const [scrolled, setScrolled] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    
    // Clock interval
    const timer = setInterval(() => {
        setCurrentTime(new Date());
    }, 1000);

    window.addEventListener('scroll', handleScroll);
    return () => {
        window.removeEventListener('scroll', handleScroll);
        clearInterval(timer);
    };
  }, []);

  // Format Date: "Mon, 14 Aug"
  const dateString = currentTime.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'short' });
  // Format Time: "14:02"
  const timeString = currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'py-4 bg-black/80 backdrop-blur-md border-b border-white/5' : 'py-8 bg-transparent'}`}>
      <style>{`
        .glitch-wrapper {
            position: relative;
        }
        .glitch-wrapper:hover::before,
        .glitch-wrapper:hover::after {
            content: "COSMICWATCH.";
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0.8;
            background: black;
        }
        .glitch-wrapper:hover::before {
            color: #0ff;
            animation: glitch-anim-1 0.4s infinite linear alternate-reverse;
        }
        .glitch-wrapper:hover::after {
            color: #f0f;
            animation: glitch-anim-2 0.4s infinite linear alternate-reverse;
        }
        @keyframes glitch-anim-1 {
            0% { clip-path: inset(20% 0 80% 0); transform: translate(-2px, 1px); }
            20% { clip-path: inset(60% 0 10% 0); transform: translate(2px, -1px); }
            40% { clip-path: inset(40% 0 50% 0); transform: translate(-2px, 2px); }
            60% { clip-path: inset(80% 0 5% 0); transform: translate(2px, -2px); }
            80% { clip-path: inset(10% 0 60% 0); transform: translate(-1px, 1px); }
            100% { clip-path: inset(30% 0 20% 0); transform: translate(1px, -1px); }
        }
        @keyframes glitch-anim-2 {
            0% { clip-path: inset(10% 0 60% 0); transform: translate(2px, -1px); }
            20% { clip-path: inset(80% 0 5% 0); transform: translate(-2px, 2px); }
            40% { clip-path: inset(30% 0 20% 0); transform: translate(1px, 1px); }
            60% { clip-path: inset(10% 0 80% 0); transform: translate(-1px, -2px); }
            80% { clip-path: inset(50% 0 30% 0); transform: translate(2px, 1px); }
            100% { clip-path: inset(20% 0 70% 0); transform: translate(-2px, -1px); }
        }
      `}</style>
      <div className="container mx-auto px-6 md:px-12 flex justify-between items-center">
        <div 
            className="text-2xl font-bold tracking-tighter cursor-pointer glitch-wrapper" 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
            COSMICWATCH.
        </div>
        
        <div className="hidden md:flex items-center space-x-12 text-sm font-medium text-gray-300">
          <a href="#dashboard" className="hover:text-white transition-colors hover:scale-105 transform duration-200">Dashboard</a>
          <a href="#sightings" className="hover:text-white transition-colors hover:scale-105 transform duration-200">Sightings</a>
          <a href="#uplink" className="hover:text-white transition-colors hover:scale-105 transform duration-200">Uplink</a>
        </div>

        <div className="flex items-center gap-6">
            {userRole === 'admin' && (
                <button 
                    onClick={onAdminClick}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-bold uppercase tracking-widest hover:bg-red-500/20 transition-all hover:shadow-[0_0_15px_rgba(239,68,68,0.3)]"
                >
                    <Shield size={14} />
                    <span>Admin</span>
                </button>
            )}

            <div className="flex flex-col items-end">
                <div 
                    onClick={onProfileClick}
                    className="flex items-center justify-center w-10 h-10 rounded-full border border-white/20 hover:bg-white hover:text-black transition-all cursor-pointer group relative hover:shadow-[0_0_15px_rgba(255,255,255,0.4)]"
                >
                    <User size={18} />
                    {/* Active Indicator */}
                    <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-black animate-pulse"></span>
                </div>
                {/* Date and Time Display */}
                <div className="mt-1 text-[10px] text-gray-400 font-mono text-right leading-tight">
                    <div>{timeString}</div>
                    <div className="opacity-60">{dateString}</div>
                </div>
            </div>
        </div>
      </div>
    </nav>
  );
};