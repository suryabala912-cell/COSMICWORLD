import React, { useRef, useMemo, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

interface OrbitingObjectProps {
  data: {
    id: string;
    name: string;
    distance: number;
    speed: number;
    size: number;
    color: string;
    risk: string;
  };
  isSelected: boolean;
  onSelect: (data: any) => void;
}

export const OrbitingObject: React.FC<OrbitingObjectProps> = ({ data, isSelected, onSelect }) => {
  const meshRef = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);

  // Random initial phase so objects don't all start at the same angle
  const initialPhase = useMemo(() => Math.random() * Math.PI * 2, []);

  // Generate elliptical orbit path geometry
  const orbitPath = useMemo(() => {
    const curve = new THREE.EllipseCurve(
      0, 0,            // ax, aY
      data.distance, data.distance * 0.85, // xRadius, yRadius (0.85 makes it elliptical)
      0, 2 * Math.PI,  // aStartAngle, aEndAngle
      false,           // aClockwise
      0                // aRotation
    );
    const points = curve.getPoints(128);
    return new THREE.BufferGeometry().setFromPoints(points);
  }, [data.distance]);

  useFrame(({ clock }) => {
    if (meshRef.current) {
      // Calculate angle based on time, speed, and initial random offset
      const t = clock.getElapsedTime() * data.speed + initialPhase;
      
      // Update position: Elliptical orbit on X/Z plane
      meshRef.current.position.x = Math.cos(t) * data.distance;
      meshRef.current.position.z = Math.sin(t) * (data.distance * 0.85);
      
      // Add slight vertical oscillation for a more dynamic 3D feel
      meshRef.current.position.y = Math.sin(t * 1.5) * (data.size * 0.5);
      
      // Self rotation
      meshRef.current.rotation.x += 0.005;
      meshRef.current.rotation.y += 0.01;
    }
  });

  return (
    <group>
      {/* Orbit Path Visualization */}
      <lineLoop geometry={orbitPath} rotation={[Math.PI / 2, 0, 0]}>
        <lineBasicMaterial 
            color={isSelected ? "#ffffff" : data.color} 
            transparent 
            opacity={isSelected ? 0.5 : 0.15} 
            linewidth={1}
        />
      </lineLoop>

      {/* The Object Mesh */}
      <group ref={meshRef}>
        <mesh 
            onClick={(e) => { e.stopPropagation(); onSelect(data); }}
            onPointerOver={() => setHovered(true)}
            onPointerOut={() => setHovered(false)}
        >
          <dodecahedronGeometry args={[data.size, 0]} />
          <meshStandardMaterial 
            color={hovered || isSelected ? "#ffffff" : "#888888"} 
            roughness={0.8}
            metalness={0.2}
            emissive={isSelected ? data.color : "#000000"}
            emissiveIntensity={isSelected ? 0.5 : 0}
          />
        </mesh>

        {/* Floating Label */}
        {(hovered || isSelected) && (
             <Html position={[0, data.size + 1.5, 0]} center distanceFactor={15} zIndexRange={[100, 0]}>
                <div className="bg-black/90 border border-white/20 px-3 py-1.5 rounded-lg text-xs text-white whitespace-nowrap backdrop-blur-md pointer-events-none select-none flex flex-col items-center shadow-xl">
                    <span className="font-bold">{data.name}</span>
                    <span className={`text-[9px] uppercase tracking-wider mt-0.5 ${
                        data.risk === 'HIGH' ? 'text-red-400' :
                        data.risk === 'MEDIUM' ? 'text-yellow-400' : 'text-green-400'
                    }`}>{data.risk} RISK</span>
                </div>
            </Html>
        )}
        
        {/* Selection Indicator Ring */}
        {isSelected && (
            <mesh rotation={[Math.PI / 2, 0, 0]}>
                <ringGeometry args={[data.size * 1.4, data.size * 1.5, 32]} />
                <meshBasicMaterial color={data.color} transparent opacity={0.8} side={THREE.DoubleSide} />
            </mesh>
        )}
      </group>
    </group>
  );
};