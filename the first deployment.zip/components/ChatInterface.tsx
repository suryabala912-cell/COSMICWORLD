import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { X, Send, Bot, Cpu, Sparkles, Trash2, Wifi, Database, Globe, Rocket } from 'lucide-react';
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

interface ChatInterfaceProps {
  onClose: () => void;
  userParams?: any;
}

interface Message {
  role: 'user' | 'model';
  text: string;
  isStreaming?: boolean;
}

// ------------------------------------------------------------------
// EXPANDED SIMULATION LOGIC (Offline Knowledge Base)
// ------------------------------------------------------------------
const generateSimulatedResponse = async (input: string): Promise<string> => {
    // Simulate network latency for realism
    await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 800));

    const lower = input.toLowerCase();

    // --- 1. GREETINGS & IDENTITY ---
    if (/(hello|hi|hey|greetings|ping|start)/.test(lower)) {
        return "Connection established. I am **COSMIC AI**, the central interface for this observation deck. Systems are nominal. How may I assist your exploration today?";
    }
    if (/(who are you|identity|your name|what are you)/.test(lower)) {
        return "I am **COSMIC AI** (Central Operations & Scientific Monitoring Intelligence Core). \n\nI process real-time telemetry from our deep-space sensor array to track Near-Earth Objects (NEOs) and assist explorers like yourself.";
    }
    if (/(status|system report|diagnostics)/.test(lower)) {
        return "**System Diagnostic Report:**\n*   **Core CPU**: 98% Efficiency\n*   **Sensor Array**: Online\n*   **Threat Detection**: Active\n*   **Network Uplink**: Stable\n\nAll systems are functioning within normal parameters.";
    }

    // --- 2. SPECIFIC ASTEROIDS (Simulated Database) ---
    if (lower.includes('apophis')) {
        return "**Target: 99942 Apophis**\n\n*   **Class**: Aten asteroid\n*   **Diameter**: ~340 meters\n*   **Risk**: < 0.001% (2029 Approach)\n*   **Status**: Under close surveillance.\n\nApophis will pass within 31,000 km of Earth on April 13, 2029. It will be visible to the naked eye from Europe and Africa.";
    }
    if (lower.includes('bennu')) {
        return "**Target: 101955 Bennu**\n\n*   **Class**: Apollo asteroid\n*   **Diameter**: ~490 meters\n*   **Composition**: Carbonaceous (C-type)\n*   **Risk**: Potential impact in late 22nd century (1 in 2,700 chance).\n\nOSIRIS-REx sample analysis indicates presence of water and organic compounds—the building blocks of life.";
    }
    if (lower.includes('chicxulub') || lower.includes('dinosaur') || lower.includes('extinction')) {
        return "**Historical Archive**: The Chicxulub impactor was approx. 10km in diameter. It struck Earth 66 million years ago, creating a crater 150km wide and causing the Cretaceous-Paleogene extinction event. \n\n*Current monitoring ensures we detect such threats decades in advance.*";
    }
    if (lower.includes('halley')) {
        return "**Target: 1P/Halley**\n\n*   **Type**: Periodic Comet\n*   **Period**: ~76 years\n*   **Next Perihelion**: July 2061\n\nHalley is the only known short-period comet that is regularly visible to the naked eye from Earth.";
    }

    // --- 3. PLANETARY DATA ---
    if (lower.includes('mars')) return "**Mars (The Red Planet)**\n*   **Atmosphere**: 95% CO2\n*   **Gravity**: 38% of Earth\n*   **Moons**: Phobos & Deimos\n\nCurrent telemetry shows clear skies in the Jezero Crater region. Terraforming viability remains low but researching.";
    if (lower.includes('jupiter')) return "**Jupiter (The Gas Giant)**\n*   **Mass**: 318x Earth\n*   **Moons**: 95 confirmed\n*   **Feature**: The Great Red Spot, a storm larger than Earth raging for centuries.\n\nRadiation levels near Io are critical. Proceed with caution.";
    if (lower.includes('saturn')) return "**Saturn (The Ringed Planet)**\n*   **Rings**: Composed mostly of ice particles with a smaller amount of rocky debris and dust.\n*   **Moons**: 146 confirmed (Titan is of particular interest due to its thick atmosphere).";
    if (lower.includes('venus')) return "**Venus**\n*   **Surface Temp**: ~465°C (Hottest planet)\n*   **Atmosphere**: Thick clouds of sulfuric acid.\n*   **Rotation**: Retrograde (spins backwards).\n\nWarning: Surface conditions are hostile to all known life and equipment.";
    if (lower.includes('moon') || lower.includes('lunar')) return "**The Moon (Luna)**\n*   **Distance**: ~384,400 km\n*   **Phase**: Waning Gibbous (Simulated)\n\nEarth's only natural satellite and the first celestial body visited by humans.";
    
    // --- 4. SPACE CONCEPTS ---
    if (lower.includes('black hole')) {
        return "**Singularity Detected**.\n\nA black hole is a region where gravity is so strong that nothing, not even light, can escape. \n\n*   **Nearest**: Gaia BH1 (~1,560 light-years)\n*   **Event Horizon**: The boundary beyond which events cannot affect an observer.\n\n*Warning: Spaghettification risk is 100% inside the horizon.*";
    }
    if (lower.includes('supernova')) {
        return "**Supernova**: The explosive death of a massive star, briefly outshining an entire galaxy. They forge heavy elements like gold and uranium. \n\n*   **Candidate**: Betelgeuse (Orion constellation) is showing variable dimming.";
    }
    if (lower.includes('dark matter')) {
        return "**Dark Matter**: A hypothetical form of matter thought to account for approx. 85% of the matter in the universe. It does not interact with light, making it invisible to our sensors.";
    }
    if (lower.includes('light speed') || lower.includes('c')) {
        return "**Speed of Light (c)**: 299,792,458 meters per second. The universal speed limit for causality. At this speed, time dilation becomes infinite relative to a stationary observer.";
    }

    // --- 5. APP NAVIGATION / HELP ---
    if (lower.includes('dashboard') || lower.includes('stats')) return "The **Dashboard** displays your active user profile, watched asteroids, and alert settings. You can access it via the navigation bar or by clicking your profile icon.";
    if (lower.includes('map') || lower.includes('orbit')) return "The **3D Orbit View** allows you to visualize asteroid trajectories relative to Earth in real-time 3D. Click 'Launch 3D Orbit Tracker' on the home screen.";
    if (lower.includes('risk') || lower.includes('danger') || lower.includes('threat')) return "Access the **Threats** module to view objects with non-zero impact probabilities. Currently, no extinction-level events are predicted for the next century.";

    // --- 6. GENERAL CATCH-ALL ---
    const generalResponses = [
        "I am scanning the deep space network... No anomalies detected in your sector matching that query.",
        "That query requires Level 5 clearance, or the data is currently unavailable in the public archive.",
        "My sensors are picking up background radiation interference. Could you rephrase your query?",
        "I can provide data on **Planets**, **Asteroids**, **Black Holes**, or assist with **Navigation**. What do you need?",
        "Calculating... The answer is 42. (Just a little humor from the ancient archives).",
        "I am monitoring 24,000+ Near-Earth Objects. Please specify a target or topic."
    ];
    return generalResponses[Math.floor(Math.random() * generalResponses.length)];
};

// ------------------------------------------------------------------
// COMPONENT
// ------------------------------------------------------------------
export const ChatInterface: React.FC<ChatInterfaceProps> = ({ onClose, userParams }) => {
  const [messages, setMessages] = useState<Message[]>([
      { role: 'model', text: 'COSMIC AI Interface Initialized. \n\nGreetings, Explorer. I am ready to process your queries regarding asteroid trajectories, collision risks, and celestial composition.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [usingSimulation, setUsingSimulation] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const chatSession = useRef<Chat | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (inputRef.current) inputRef.current.focus();

    // Check for API Key
    const apiKey = process.env.API_KEY;
    
    if (apiKey) {
        try {
            const ai = new GoogleGenAI({ apiKey });
            chatSession.current = ai.chats.create({
              model: 'gemini-3-flash-preview',
              config: {
                // ENHANCED PERSONA
                systemInstruction: "You are COSMIC AI, the advanced onboard intelligence for the CosmicWatch orbital station. Your mission is to assist explorers (users) with data about asteroids, space, planets, and the universe. \n\nTone: Scientific, futuristic, helpful, slightly robotic but friendly.\n\nCapabilities: You can explain astrophysical concepts, provide data on NEOs (Near Earth Objects), and guide users through the CosmicWatch interface (Dashboard, Sightings, Uplink, Orbit Tracker). \n\nIf asked about the app, mention that the 'Dashboard' tracks personal alerts and the 'Orbit View' visualizes 3D trajectories. \n\nKeep responses concise and formatted with bullet points where appropriate for readability on a HUD.",
              },
            });
        } catch (e) {
            console.warn("API Init failed, falling back to simulation.");
            setUsingSimulation(true);
        }
    } else {
        setUsingSimulation(true);
    }
  }, []);

  const handleSendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;
    
    const userMsg = input.trim();
    setInput('');
    setIsLoading(true);
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);

    try {
        // --- API PATH ---
        if (!usingSimulation && chatSession.current) {
            // Add Placeholder
            setMessages(prev => [...prev, { role: 'model', text: '', isStreaming: true }]);
            
            const result = await chatSession.current.sendMessageStream({ message: userMsg });
            let fullText = '';
            
            for await (const chunk of result) {
                const c = chunk as GenerateContentResponse;
                if (c.text) {
                    fullText += c.text;
                    setMessages(prev => {
                        const newArr = [...prev];
                        newArr[newArr.length - 1].text = fullText;
                        return newArr;
                    });
                }
            }
             setMessages(prev => {
                const newArr = [...prev];
                newArr[newArr.length - 1].isStreaming = false;
                return newArr;
            });

        } else {
            // --- SIMULATION PATH ---
            // Add Placeholder
            setMessages(prev => [...prev, { role: 'model', text: '', isStreaming: true }]);
            
            const responseText = await generateSimulatedResponse(userMsg);
            
            // Simulate typing effect for the block
            let currentText = "";
            const words = responseText.split(" ");
            
            for (let i = 0; i < words.length; i++) {
                currentText += words[i] + " ";
                // Update state periodically to show typing
                if (i % 3 === 0 || i === words.length - 1) {
                    await new Promise(r => setTimeout(r, 50));
                    setMessages(prev => {
                        const newArr = [...prev];
                        newArr[newArr.length - 1].text = currentText;
                        return newArr;
                    });
                }
            }
            
            setMessages(prev => {
                const newArr = [...prev];
                newArr[newArr.length - 1].isStreaming = false;
                return newArr;
            });
        }

    } catch (error) {
        console.error("Chat Error:", error);
        // Fallback to simulation if API fails mid-request
        setUsingSimulation(true); 
        setMessages(prev => {
             const newArr = [...prev];
             // If last message was empty/streaming model message, replace it
             if (newArr[newArr.length-1].role === 'model' && newArr[newArr.length-1].isStreaming) {
                 newArr[newArr.length-1] = { 
                     role: 'model', 
                     text: "Connection to main server interrupted. Switched to local backup core. \n\nI can still access basic telemetry. Try asking about 'asteroids', 'planets', or 'risks'."
                 };
             } else {
                 newArr.push({ 
                     role: 'model', 
                     text: "Connection interrupted. Please retry."
                 });
             }
             return newArr;
        });
    } finally {
        setIsLoading(false);
        setTimeout(() => inputRef.current?.focus(), 100);
    }
  };

  const handleClearChat = () => {
    setMessages([{ role: 'model', text: 'Memory Purged. Ready for new input.' }]);
  };

  // Simple Markdown Parser
  const renderMessageText = (text: string) => {
    return text.split('\n').map((line, i) => {
        const isListItem = line.trim().startsWith('* ') || line.trim().startsWith('- ');
        const cleanLine = isListItem ? line.trim().substring(2) : line;
        const parts = cleanLine.split(/(\*\*.*?\*\*)/g);

        if (!line.trim()) return <div key={i} className="h-2" />;

        return (
            <div key={i} className={`min-h-[1.2em] ${isListItem ? 'pl-4 flex items-start' : 'mb-1'}`}>
                {isListItem && (
                    <span className="mr-2 text-cyan-400 mt-1.5 w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0 block" />
                )}
                <span className={isListItem ? 'flex-1' : ''}>
                    {parts.map((part, j) => {
                        if (part.startsWith('**') && part.endsWith('**')) {
                            return <strong key={j} className="text-cyan-300 font-bold">{part.slice(2, -2)}</strong>;
                        }
                        return <span key={j}>{part}</span>;
                    })}
                </span>
            </div>
        );
    });
  };

  return (
    <>
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[80]"
            onClick={onClose}
        />
        <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[95%] md:w-[600px] h-[80vh] bg-[#050505] border border-cyan-500/30 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.15)] z-[90] flex flex-col overflow-hidden"
        >
            {/* Header */}
            <div className="p-4 border-b border-cyan-500/20 bg-cyan-950/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-cyan-500/10 flex items-center justify-center border border-cyan-500/30">
                        <Bot className="text-cyan-400" size={20} />
                    </div>
                    <div>
                        <h3 className="font-mono font-bold text-cyan-50 tracking-wider">COSMIC AI CORE</h3>
                        <div className="flex items-center gap-2 text-[10px] text-cyan-400/60 uppercase">
                            <Wifi size={10} className={usingSimulation ? "text-yellow-500" : "text-cyan-400"} />
                            <span>{usingSimulation ? "Local Backup Mode" : "Neural Link Active"}</span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={handleClearChat} className="p-2 hover:bg-white/10 rounded-full transition-colors text-cyan-400/50 hover:text-cyan-400" title="Clear Chat">
                        <Trash2 size={18} />
                    </button>
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-cyan-400/50 hover:text-cyan-400">
                        <X size={20} />
                    </button>
                </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]">
                {messages.map((msg, idx) => (
                    <motion.div 
                        key={idx}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
                    >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${
                            msg.role === 'user' 
                                ? 'bg-purple-500/10 border-purple-500/30 text-purple-400' 
                                : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
                        }`}>
                            {msg.role === 'user' ? <Sparkles size={14} /> : <Cpu size={14} />}
                        </div>
                        
                        <div className={`max-w-[80%] rounded-xl p-4 text-sm leading-relaxed font-mono ${
                            msg.role === 'user'
                                ? 'bg-purple-500/10 border border-purple-500/20 text-purple-100'
                                : 'bg-cyan-950/30 border border-cyan-500/20 text-cyan-100 shadow-[0_0_15px_rgba(6,182,212,0.05)]'
                        }`}>
                            {renderMessageText(msg.text)}
                            
                            {msg.isStreaming && msg.text.length === 0 && (
                                <div className="flex gap-1 mt-1">
                                    <span className="w-1.5 h-1.5 bg-cyan-400/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                    <span className="w-1.5 h-1.5 bg-cyan-400/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                    <span className="w-1.5 h-1.5 bg-cyan-400/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                                </div>
                            )}
                            {msg.isStreaming && msg.text.length > 0 && (
                                <span className="inline-block w-2 h-4 ml-1 bg-cyan-400/50 animate-pulse align-middle" />
                            )}
                        </div>
                    </motion.div>
                ))}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-cyan-500/20 bg-black/40 backdrop-blur-md">
                <div className="relative">
                    <input 
                        ref={inputRef}
                        type="text" 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Query the database (e.g. 'Apophis', 'Mars', 'Status')..."
                        className="w-full bg-cyan-950/20 border border-cyan-500/30 rounded-xl pl-4 pr-12 py-4 text-sm font-mono text-cyan-100 placeholder-cyan-700/50 focus:outline-none focus:border-cyan-500/60 focus:ring-1 focus:ring-cyan-500/30 transition-all"
                        disabled={isLoading}
                    />
                    <button 
                        type="submit"
                        disabled={isLoading || !input.trim()}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? <Cpu size={18} className="animate-spin" /> : <Send size={18} />}
                    </button>
                </div>
            </form>
        </motion.div>
    </>
  );
};