import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export const CustomCursor = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isPointer, setIsPointer] = useState(false);
  const [isClicking, setIsClicking] = useState(false);

  useEffect(() => {
    const mouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
      
      const target = e.target as HTMLElement;
      // Check if hovering over clickable elements
      const isClickable = 
        window.getComputedStyle(target).cursor === 'pointer' ||
        target.tagName === 'BUTTON' ||
        target.tagName === 'A';
      
      setIsPointer(isClickable);
    };

    const mouseDown = () => setIsClicking(true);
    const mouseUp = () => setIsClicking(false);

    window.addEventListener("mousemove", mouseMove);
    window.addEventListener("mousedown", mouseDown);
    window.addEventListener("mouseup", mouseUp);

    return () => {
      window.removeEventListener("mousemove", mouseMove);
      window.removeEventListener("mousedown", mouseDown);
      window.removeEventListener("mouseup", mouseUp);
    };
  }, []);

  return (
    <>
        {/* Main Center Dot */}
        <motion.div
            className="fixed top-0 left-0 w-1.5 h-1.5 bg-cyan-400 rounded-full pointer-events-none z-[9999] hidden md:block shadow-[0_0_10px_rgba(34,211,238,0.8)]"
            animate={{ x: mousePosition.x - 3, y: mousePosition.y - 3 }}
            transition={{ type: "tween", ease: "linear", duration: 0 }}
        />
        
        {/* Outer Tech Ring */}
        <motion.div
            className="fixed top-0 left-0 pointer-events-none z-[9998] hidden md:flex items-center justify-center border border-cyan-500/30 rounded-full"
            animate={{ 
                x: mousePosition.x - (isPointer ? 20 : 12), 
                y: mousePosition.y - (isPointer ? 20 : 12),
                width: isPointer ? 40 : 24,
                height: isPointer ? 40 : 24,
                scale: isClicking ? 0.8 : 1,
                borderColor: isPointer ? 'rgba(34,211,238, 0.8)' : 'rgba(34,211,238, 0.3)',
                backgroundColor: isPointer ? 'rgba(34,211,238, 0.05)' : 'transparent'
            }}
            transition={{ type: "spring", stiffness: 300, damping: 20, mass: 0.5 }}
        >
            {/* Crosshair accents on the ring */}
            <motion.div 
                animate={{ rotate: isPointer ? 180 : 0 }}
                transition={{ duration: 0.5 }}
                className="w-full h-full relative"
            >
                {isPointer && (
                    <>
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-[2px] w-0.5 h-1.5 bg-cyan-400" />
                        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-[2px] w-0.5 h-1.5 bg-cyan-400" />
                        <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-[2px] w-1.5 h-0.5 bg-cyan-400" />
                        <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-[2px] w-1.5 h-0.5 bg-cyan-400" />
                    </>
                )}
            </motion.div>
        </motion.div>
    </>
  );
};