import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Info, Target, MousePointer2, AlertTriangle, Activity, Ruler } from 'lucide-react';
import { SpaceScene } from './SpaceScene';

interface OrbitViewProps {
  onClose: () => void;
}

// Mock Data for the simulation
const ASTEROID_DATA = [
    { id: '1', name: '99942 Apophis', distance: 10, speed: 0.2, size: 0.4, color: '#ef4444', risk: 'HIGH', impact: '2029' },
    { id: '2', name: '101955 Bennu', distance: 15, speed: 0.15, size: 0.5, color: '#eab308', risk: 'MEDIUM', impact: '2182' },
    { id: '3', name: '2024 YR4', distance: 22, speed: 0.1, size: 0.2, color: '#3b82f6', risk: 'LOW', impact: '2032' },
    { id: '4', name: 'Eros 433', distance: 28, speed: 0.08, size: 0.8, color: '#a855f7', risk: 'NONE', impact: 'N/A' },
    { id: '5', name: 'Icarus', distance: 8, speed: 0.4, size: 0.3, color: '#f97316', risk: 'MEDIUM', impact: 'N/A' },
];

export const OrbitView: React.FC<OrbitViewProps> = ({ onClose }) => {
  const [selectedAsteroid, setSelectedAsteroid] = useState<any>(null);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] bg-black text-white"
    >
      {/* 3D Scene Layer */}
      <div className="absolute inset-0 z-0">
         <SpaceScene 
            asteroids={ASTEROID_DATA} 
            selectedId={selectedAsteroid?.id || null} 
            onSelectAsteroid={setSelectedAsteroid} 
         />
      </div>

      {/* UI Overlay Layer */}
      <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-between p-6 md:p-10">
         
         {/* Top Bar */}
         <div className="flex justify-between items-start pointer-events-auto">
            <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-2xl p-6 max-w-sm">
                <h1 className="text-2xl font-light tracking-tight mb-1">Live Orbit Tracker</h1>
                <p className="text-sm text-gray-400">Real-time simulation of Near Earth Objects.</p>
                <div className="flex gap-4 mt-4 text-xs font-mono text-gray-500">
                    <div className="flex items-center gap-2">
                        <MousePointer2 size={14} />
                        <span>Select Object</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <MousePointer2 size={14} className="rotate-90" />
                        <span>Rotate/Zoom</span>
                    </div>
                </div>
            </div>

            <button 
                onClick={onClose}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md flex items-center justify-center transition-colors border border-white/10"
            >
                <X size={24} />
            </button>
         </div>

         {/* Bottom Data Panel (Conditional) */}
         <div className="flex justify-end pointer-events-auto">
            {selectedAsteroid ? (
                <motion.div 
                   key={selectedAsteroid.id}
                   initial={{ opacity: 0, x: 50 }}
                   animate={{ opacity: 1, x: 0 }}
                   className="bg-black/80 backdrop-blur-xl border border-white/10 rounded-2xl p-6 w-full md:w-96 shadow-2xl"
                >
                    <div className="flex justify-between items-start mb-6">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <Target size={16} className="text-cyan-400" />
                                <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">Target Lock</span>
                            </div>
                            <h2 className="text-3xl font-medium">{selectedAsteroid.name}</h2>
                        </div>
                        <div className={`px-3 py-1 rounded text-xs font-bold border ${
                            selectedAsteroid.risk === 'HIGH' ? 'bg-red-500/20 text-red-500 border-red-500/30' :
                            selectedAsteroid.risk === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30' :
                            'bg-green-500/20 text-green-500 border-green-500/30'
                        }`}>
                            {selectedAsteroid.risk}
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="bg-white/5 rounded-lg p-3">
                            <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                                <Ruler size={12} />
                                <span>Orbit Distance</span>
                            </div>
                            <div className="text-lg">{selectedAsteroid.distance} <span className="text-xs text-gray-500">AU (Sim)</span></div>
                        </div>
                        <div className="bg-white/5 rounded-lg p-3">
                            <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                                <Activity size={12} />
                                <span>Relative Velocity</span>
                            </div>
                            <div className="text-lg">{(selectedAsteroid.speed * 100).toFixed(1)} <span className="text-xs text-gray-500">km/s</span></div>
                        </div>
                        <div className="bg-white/5 rounded-lg p-3">
                             <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                                <Info size={12} />
                                <span>Est. Diameter</span>
                            </div>
                            <div className="text-lg">{(selectedAsteroid.size * 500).toFixed(0)} <span className="text-xs text-gray-500">m</span></div>
                        </div>
                        <div className="bg-white/5 rounded-lg p-3">
                             <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                                <AlertTriangle size={12} />
                                <span>Impact Window</span>
                            </div>
                            <div className="text-lg text-white">{selectedAsteroid.impact}</div>
                        </div>
                    </div>

                    <button 
                        onClick={() => setSelectedAsteroid(null)}
                        className="w-full py-3 rounded-xl bg-white text-black font-bold uppercase tracking-widest text-xs hover:bg-gray-200 transition-colors"
                    >
                        Clear Selection
                    </button>
                </motion.div>
            ) : (
                <div className="bg-black/40 backdrop-blur-md border border-white/5 rounded-xl p-4 text-sm text-gray-500 font-mono">
                    System Idle. Select a target to view telemetry.
                </div>
            )}
         </div>

      </div>
    </motion.div>
  );
};