import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Radar, User, Radio, MapPin, Users, Globe } from 'lucide-react';

interface ExplorerNetProps {
  onClose: () => void;
}

const MOCK_USERS = [
    { id: 1, name: 'Cmdr. Shepard', location: 'Lunar Base Alpha', status: 'Online', dist: '384,400 km' },
    { id: 2, name: 'Dr. Brand', location: 'ISS Module 4', status: 'Busy', dist: '408 km' },
    { id: 3, name: 'Explorer-77', location: 'Sector 7', status: 'Online', dist: 'Unknown' },
    { id: 4, name: 'Watcher_X', location: 'Deep Space Network', status: 'Idle', dist: '1.2M km' },
];

export const ExplorerNet: React.FC<ExplorerNetProps> = ({ onClose }) => {
  const [status, setStatus] = useState<'scanning' | 'found'>('scanning');
  const [scanText, setScanText] = useState('Initializing Wideband Scan...');
  const [foundUsers, setFoundUsers] = useState<typeof MOCK_USERS>([]);

  useEffect(() => {
    // Sequence of scanning text
    const texts = [
        'Triangulating Local Signals...',
        'Pinging Deep Space Network...',
        'Handshake Protocols Active...',
        'Decryption Complete.'
    ];

    let i = 0;
    const interval = setInterval(() => {
        if (i < texts.length) {
            setScanText(texts[i]);
            i++;
        }
    }, 800);

    // Finish scan
    const timeout = setTimeout(() => {
        setStatus('found');
        setFoundUsers(MOCK_USERS);
        clearInterval(interval);
    }, 3500);

    return () => {
        clearInterval(interval);
        clearTimeout(timeout);
    };
  }, []);

  return (
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[150] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center text-white font-mono"
    >
        <button 
            onClick={onClose}
            className="absolute top-8 right-8 p-3 bg-white/5 hover:bg-white/10 rounded-full transition-colors border border-white/10"
        >
            <X size={24} />
        </button>

        <AnimatePresence mode="wait">
            {status === 'scanning' ? (
                <motion.div 
                    key="scanning"
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 1.2, opacity: 0 }}
                    className="flex flex-col items-center"
                >
                    {/* Radar Animation */}
                    <div className="relative w-64 h-64 mb-8">
                        <div className="absolute inset-0 rounded-full border border-purple-500/30" />
                        <div className="absolute inset-[15%] rounded-full border border-purple-500/30" />
                        <div className="absolute inset-[30%] rounded-full border border-purple-500/30" />
                        <div className="absolute inset-0 rounded-full border-t border-purple-400/80 animate-[spin_2s_linear_infinite]" />
                        <div className="absolute inset-0 rounded-full bg-purple-500/5 animate-pulse" />
                        
                        {/* Center Icon */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                            <Radar size={48} className="text-purple-400" />
                        </div>
                    </div>
                    
                    <h2 className="text-2xl font-bold tracking-widest text-purple-200 mb-2">SEARCHING FOR USERS</h2>
                    <div className="flex items-center gap-2 text-purple-400/60 text-sm">
                        <Radio size={14} className="animate-pulse" />
                        <span>{scanText}</span>
                    </div>
                </motion.div>
            ) : (
                <motion.div 
                    key="found"
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="w-full max-w-4xl px-6"
                >
                    <div className="text-center mb-10">
                        <div className="inline-flex items-center justify-center p-3 rounded-full bg-green-500/10 text-green-400 mb-4 border border-green-500/20">
                            <Users size={32} />
                        </div>
                        <h2 className="text-3xl font-light mb-2">Network Uplink Established</h2>
                        <p className="text-gray-400">4 Active Explorers found in your vicinity.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {foundUsers.map((user, idx) => (
                            <motion.div
                                key={user.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.1 }}
                                className="bg-white/5 border border-white/10 p-4 rounded-xl flex items-center justify-between hover:bg-white/10 transition-colors group cursor-pointer"
                            >
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-300 border border-purple-500/30">
                                        <User size={20} />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-white group-hover:text-purple-300 transition-colors">{user.name}</h3>
                                        <div className="flex items-center gap-3 text-xs text-gray-400 mt-1">
                                            <span className="flex items-center gap-1"><MapPin size={10} /> {user.location}</span>
                                            <span className="flex items-center gap-1"><Globe size={10} /> {user.dist}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex flex-col items-end gap-2">
                                    <span className="px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 border border-green-500/20 text-[10px] uppercase font-bold tracking-wider">
                                        {user.status}
                                    </span>
                                    <button className="text-xs text-purple-400 hover:text-white transition-colors">
                                        Connect +
                                    </button>
                                </div>
                            </motion.div>
                        ))}
                    </div>

                    <div className="mt-8 text-center">
                        <button className="px-6 py-3 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold tracking-wider transition-colors">
                            BROADCAST SIGNAL
                        </button>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    </motion.div>
  );
};