import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Features } from './components/Features';
import { Trips } from './components/Trips';
import { Tickets } from './components/Tickets';
import { Footer } from './components/Footer';
import { Auth } from './components/Auth';
import { Dashboard } from './components/Dashboard';
import { AsteroidDetails } from './components/AsteroidDetails';
import { Threats } from './components/Threats';
import { Proximity } from './components/Proximity';
import { UserMonitoring } from './components/UserMonitoring';
import { CosmicChat } from './components/CosmicChat';
import { AdminPanel } from './components/AdminPanel';
import { OrbitView } from './components/OrbitView';
import { StarField } from './components/StarField';
import { CustomCursor } from './components/CustomCursor';
import { ExplorerNet } from './components/ExplorerNet';
import { AnimatePresence, motion, useScroll, useTransform } from 'framer-motion';
import { Lock, LogIn } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<any>(null);
  
  // Feature State
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isAsteroidPageOpen, setIsAsteroidPageOpen] = useState(false);
  const [isThreatsPageOpen, setIsThreatsPageOpen] = useState(false);
  const [isProximityPageOpen, setIsProximityPageOpen] = useState(false);
  const [isMonitoringPageOpen, setIsMonitoringPageOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [isOrbitViewOpen, setIsOrbitViewOpen] = useState(false);
  const [isExplorerNetOpen, setIsExplorerNetOpen] = useState(false);
  
  // Auth & System State
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [isRestrictionModalOpen, setIsRestrictionModalOpen] = useState(false);

  // Background Parallax Animation
  const { scrollY } = useScroll();
  // Moves the background image slightly downwards as user scrolls to create depth
  const backgroundY = useTransform(scrollY, [0, 5000], ["-10%", "10%"]);

  useEffect(() => {
    // Check local storage for persisted session
    const savedUser = localStorage.getItem('space_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setCheckingAuth(false);
  }, []);

  const handleLogin = (userData: any) => {
    setUser(userData);
    localStorage.setItem('space_user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    setIsDashboardOpen(false);
    setIsAsteroidPageOpen(false);
    setIsThreatsPageOpen(false);
    setIsProximityPageOpen(false);
    setIsMonitoringPageOpen(false);
    setIsChatOpen(false);
    setIsAdminPanelOpen(false);
    setIsOrbitViewOpen(false);
    setIsExplorerNetOpen(false);
    localStorage.removeItem('space_user');
  };

  // ------------------------------------------------------------------
  // GUEST RESTRICTION LOGIC
  // ------------------------------------------------------------------
  const handleProtectedAction = (action: () => void) => {
    // If user is guest (id starts with 'guest-'), show restriction modal
    if (user?.role === 'user' && user?.id?.startsWith('guest-')) {
      setIsRestrictionModalOpen(true);
    } else {
      action();
    }
  };

  if (checkingAuth) return null;

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen text-white selection:bg-cyan-500/30 selection:text-white relative cursor-none">
      <CustomCursor />
      
      {/* Global Fixed Background (Moon Surface / Earth Rise Theme) with Parallax */}
      <div className="fixed inset-0 z-0 bg-black overflow-hidden">
         <motion.div 
            style={{ y: backgroundY }}
            className="absolute -top-[10%] left-0 w-full h-[120vh] origin-top"
         >
            {/* Using a high-res image resembling Earth rising over Moon surface */}
            <img 
                src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop" 
                alt="Space Background" 
                className="w-full h-full object-cover opacity-70"
            />
            {/* Overlay gradient to darken the bottom for content readability */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black" />
         </motion.div>
         
         {/* Animated StarField Layer */}
         <StarField />
      </div>

      <Navbar 
        onProfileClick={() => handleProtectedAction(() => setIsDashboardOpen(true))} 
        userRole={user.role}
        onAdminClick={() => setIsAdminPanelOpen(true)}
      />
      
      <main className="relative z-10">
        <Hero onOpenOrbit={() => handleProtectedAction(() => setIsOrbitViewOpen(true))} />
        <About 
          onOpenAsteroidPage={() => handleProtectedAction(() => setIsAsteroidPageOpen(true))} 
          onOpenThreatsPage={() => handleProtectedAction(() => setIsThreatsPageOpen(true))}
          onOpenProximityPage={() => handleProtectedAction(() => setIsProximityPageOpen(true))}
          onOpenMonitoringPage={() => handleProtectedAction(() => setIsMonitoringPageOpen(true))}
        />
        <Features />
        <Trips />
        <Tickets 
            onOpenChat={() => handleProtectedAction(() => setIsChatOpen(true))} 
            onOpenExplorer={() => handleProtectedAction(() => setIsExplorerNetOpen(true))}
        />
      </main>
      
      <Footer />
      
      {/* RESTRICTED FEATURES */}
      <Dashboard 
        user={user}
        isOpen={isDashboardOpen}
        onClose={() => setIsDashboardOpen(false)}
        onLogout={handleLogout}
      />

      <AnimatePresence>
        {isAsteroidPageOpen && (
          <AsteroidDetails onBack={() => setIsAsteroidPageOpen(false)} />
        )}
        {isThreatsPageOpen && (
          <Threats onBack={() => setIsThreatsPageOpen(false)} />
        )}
        {isProximityPageOpen && (
          <Proximity onBack={() => setIsProximityPageOpen(false)} />
        )}
        {isMonitoringPageOpen && (
          <UserMonitoring onBack={() => setIsMonitoringPageOpen(false)} />
        )}
        {isChatOpen && (
          <CosmicChat onClose={() => setIsChatOpen(false)} userParams={user} />
        )}
        {isAdminPanelOpen && (
          <AdminPanel currentUser={user} onClose={() => setIsAdminPanelOpen(false)} />
        )}
        {isOrbitViewOpen && (
          <OrbitView onClose={() => setIsOrbitViewOpen(false)} />
        )}
        {isExplorerNetOpen && (
          <ExplorerNet onClose={() => setIsExplorerNetOpen(false)} />
        )}
        
        {/* GUEST RESTRICTION MODAL */}
        {isRestrictionModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setIsRestrictionModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#111] border border-white/10 p-8 rounded-2xl max-w-md w-full text-center relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent" />
              
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-red-500 border border-red-500/20">
                <Lock size={32} />
              </div>
              
              <h2 className="text-2xl font-light text-white mb-2">Restricted Access</h2>
              <p className="text-gray-400 mb-8">
                Guest clearance level is insufficient for this module. Please authenticate with a full explorer profile to access deep space telemetry and live tools.
              </p>
              
              <div className="flex flex-col gap-3">
                <button 
                  onClick={handleLogout}
                  className="w-full py-3 bg-white text-black font-bold uppercase tracking-widest rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
                >
                  <LogIn size={16} />
                  Login / Register
                </button>
                <button 
                  onClick={() => setIsRestrictionModalOpen(false)}
                  className="w-full py-3 bg-white/5 text-gray-400 font-bold uppercase tracking-widest rounded-lg hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}